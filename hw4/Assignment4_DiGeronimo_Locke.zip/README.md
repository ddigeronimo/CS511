To start this code:
~ erlc sensor.erl watcher.erl && erl
1> watcher:start().